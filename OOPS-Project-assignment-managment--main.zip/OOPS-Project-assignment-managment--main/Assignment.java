package models;

import java.io.Serializable;
import java.time.LocalDate;

public class Assignment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String projectId;
    private String studentUsername;
    private LocalDate assignedDate;
    private String submissionLink;
    private LocalDate submissionDate;
    // marks assigned by teacher/admin
    private Integer marks;
    private LocalDate marksDate;
    // optional group member details captured at submission time
    private java.util.List<GroupMember> groupMembers;
    // optional group id for this submission
    private String groupId;

    public Assignment(String projectId, String studentUsername) {
        this.projectId = projectId;
        this.studentUsername = studentUsername;
    }

    public Assignment(String projectId, String studentUsername, LocalDate assignedDate) {
        this.projectId = projectId;
        this.studentUsername = studentUsername;
        this.assignedDate = assignedDate;
    }

    public String getProjectId() { return projectId; }
    public String getStudentUsername() { return studentUsername; }
    public LocalDate getAssignedDate() { return assignedDate; }
    public String getSubmissionLink() { return submissionLink; }
    public LocalDate getSubmissionDate() { return submissionDate; }

    public Integer getMarks() { return marks; }
    public LocalDate getMarksDate() { return marksDate; }
    public java.util.List<GroupMember> getGroupMembers() { return groupMembers; }
    public String getGroupId() { return groupId; }

    public void setSubmission(String link, LocalDate when) { this.submissionLink = link; this.submissionDate = when; }

    public void setMarks(Integer marks, LocalDate when) { this.marks = marks; this.marksDate = when; }
    public void setGroupMembers(java.util.List<GroupMember> members) { this.groupMembers = members; }
    public void setGroupId(String groupId) { this.groupId = groupId; }
}
