import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import models.User;
import models.Project;

public class AssignProjectWindow extends JFrame {
    private DBHelper db;
    private User user;

    public AssignProjectWindow(DBHelper db, User user) {
        super("Assign Project"); this.db = db; this.user = user;
        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            JOptionPane.showMessageDialog(null, "Only admins can assign projects.", "Access denied", JOptionPane.WARNING_MESSAGE);
            SwingUtilities.invokeLater(() -> { dispose(); });
            return;
        }
        init();
    }

    private void init() {
        setSize(620,420); setLocationRelativeTo(null); setMinimumSize(new Dimension(520,360));
        TrailPanel bg = new TrailPanel(); bg.setLayout(new GridBagLayout());

    JPanel card = new RoundedPanel();
        card.setLayout(new BorderLayout(12,12)); card.setOpaque(false); card.setPreferredSize(new Dimension(520,320));

        // header
        JPanel header = new JPanel(new BorderLayout()); header.setOpaque(false);
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,12,8)); left.setOpaque(false);
    PulsingIcon picon = new PulsingIcon(48,48);
    JLabel iconLabel = new JLabel(new ImageIcon(picon.getImage()));
    Timer iconTimer = new Timer(90, ev -> { picon.pulse(); iconLabel.setIcon(new ImageIcon(picon.getImage())); });
    iconTimer.start();
    left.add(iconLabel);
        JLabel title = new JLabel("Assign Project"); title.setForeground(Color.WHITE); title.setFont(title.getFont().deriveFont(Font.BOLD,18f)); left.add(title);
        header.add(left, BorderLayout.WEST);

        // form
        JPanel form = new JPanel(new GridBagLayout()); form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(8,10,8,10);
        c.gridx=0; c.gridy=0; c.anchor=GridBagConstraints.EAST; JLabel projLbl = new JLabel("Project:"); projLbl.setForeground(Color.LIGHT_GRAY); projLbl.setPreferredSize(new Dimension(140, projLbl.getPreferredSize().height)); form.add(projLbl, c);
        java.util.List<Project> list = new java.util.ArrayList<>();
        for (Project p : db.getProjects()) if (p.getDepartment().equalsIgnoreCase(user.getDepartment())) list.add(p);
        String[] ids = list.stream().map(p -> p.getId()+" - "+p.getTitle()).toArray(String[]::new);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; c.fill=GridBagConstraints.HORIZONTAL; JComboBox<String> projBox = new JComboBox<>(ids); form.add(projBox, c);

    c.gridx=0; c.gridy=1; c.anchor=GridBagConstraints.EAST; JLabel studentLbl = new JLabel("Student username (optional):"); studentLbl.setForeground(Color.LIGHT_GRAY); studentLbl.setPreferredSize(new Dimension(140, studentLbl.getPreferredSize().height)); form.add(studentLbl, c);
    c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField studentF = new JTextField(20); studentF.setBackground(new Color(60,60,60)); studentF.setForeground(Color.WHITE); form.add(studentF, c);

    // allow assigning by department + division
    c.gridx=0; c.gridy=2; c.anchor=GridBagConstraints.EAST; JLabel deptLbl = new JLabel("Department:"); deptLbl.setForeground(Color.LIGHT_GRAY); deptLbl.setPreferredSize(new Dimension(140, deptLbl.getPreferredSize().height)); form.add(deptLbl, c);
    c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField deptF = new JTextField(user.getDepartment(), 16); deptF.setBackground(new Color(60,60,60)); deptF.setForeground(Color.WHITE); form.add(deptF, c);

    c.gridx=0; c.gridy=3; c.anchor=GridBagConstraints.EAST; JLabel divLbl = new JLabel("Division (optional):"); divLbl.setForeground(Color.LIGHT_GRAY); divLbl.setPreferredSize(new Dimension(140, divLbl.getPreferredSize().height)); form.add(divLbl, c);
    c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField divF = new JTextField(8); divF.setBackground(new Color(60,60,60)); divF.setForeground(Color.WHITE); form.add(divF, c);

    // group size option (admins can choose how many members per group when bulk assigning)
    c.gridx=0; c.gridy=4; c.anchor=GridBagConstraints.EAST; JLabel groupSizeLbl = new JLabel("Group size:"); groupSizeLbl.setForeground(Color.LIGHT_GRAY); groupSizeLbl.setPreferredSize(new Dimension(140, groupSizeLbl.getPreferredSize().height)); form.add(groupSizeLbl, c);
    c.gridx=1; c.anchor=GridBagConstraints.WEST; SpinnerNumberModel snm = new SpinnerNumberModel(1, 1, 50, 1); JSpinner groupSizeSpinner = new JSpinner(snm); ((JSpinner.DefaultEditor)groupSizeSpinner.getEditor()).getTextField().setBackground(new Color(60,60,60)); ((JSpinner.DefaultEditor)groupSizeSpinner.getEditor()).getTextField().setForeground(Color.WHITE); form.add(groupSizeSpinner, c);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER)); actions.setOpaque(false);
        JButton assign = new JButton("Assign"); assign.setBackground(new Color(30,144,255)); assign.setForeground(Color.WHITE); actions.add(assign);
        assign.addActionListener(e -> {
            String pick = (String)projBox.getSelectedItem(); if (pick==null) return; String projId = pick.split(" - ")[0];
            String student = studentF.getText().trim();
            String dept = deptF.getText().trim(); String div = divF.getText().trim();
            if (!student.isEmpty()) {
                db.assignProject(projId, student);
                JOptionPane.showMessageDialog(this, "Assigned to " + student);
                return;
            }
            // bulk assign to students matching dept/div
            java.util.List<models.User> studs = db.getStudentsByDeptAndDiv(dept, div);
            if (studs.isEmpty()) { JOptionPane.showMessageDialog(this, "No matching students found for the selected department/division."); return; }
            int groupSize = (int) groupSizeSpinner.getValue();
            // partition students into groups of groupSize and assign group ids like <projId>_G1, _G2, ...
            int groupIdx = 0; int assignedCount = 0;
            for (int i = 0; i < studs.size(); i++) {
                if (i % groupSize == 0) groupIdx++;
                String gid = projId + "_G" + groupIdx;
                models.User su = studs.get(i);
                // set user's group id
                db.setUserGroup(su.getUsername(), gid);
                // create assignment
                db.assignProject(projId, su.getUsername());
                assignedCount++;
            }
            JOptionPane.showMessageDialog(this, "Assigned to " + assignedCount + " students in groups of " + groupSize + ".");
        });

        JScrollPane scroll = new JScrollPane(form, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false); scroll.setBorder(BorderFactory.createEmptyBorder()); scroll.setPreferredSize(new Dimension(480,200));

        card.add(header, BorderLayout.NORTH); card.add(scroll, BorderLayout.CENTER); card.add(actions, BorderLayout.SOUTH);
        JScrollPane cardScroll = new JScrollPane(card, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cardScroll.setOpaque(false); cardScroll.getViewport().setOpaque(false); cardScroll.setBorder(BorderFactory.createEmptyBorder()); cardScroll.setPreferredSize(new Dimension(540,340));
        bg.add(cardScroll); add(bg);
    addWindowListener(new WindowAdapter() { @Override public void windowClosed(WindowEvent e) { iconTimer.stop(); } });
    }

    // Rounded panel (copied style from AddProjectWindow)
    private static class RoundedPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0,0, new Color(35,35,40,220), 0, h, new Color(22,22,26,200));
            g2.setPaint(gp);
            g2.fillRoundRect(0,0,w,h,20,20);
            g2.setColor(new Color(255,255,255,20));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0,0,w-1,h-1,20,20);
            g2.dispose();
        }
    }
}
