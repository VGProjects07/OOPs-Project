import java.awt.*;
import java.awt.image.BufferedImage;

public class PulsingIcon {
    private final int w, h;
    private final BufferedImage img;
    private float phase = 0f;
    public PulsingIcon(int w, int h) { this.w = w; this.h = h; img = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB); draw(); }
    public void pulse() { phase += 0.12f; draw(); }
    private void draw(){ Graphics2D g = img.createGraphics(); g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); g.setComposite(AlphaComposite.Clear); g.fillRect(0,0,w,h); g.setComposite(AlphaComposite.SrcOver);
        // background circle
        g.setColor(new Color(60,120,200)); g.fillOval(4,4,w-8,h-8);
        // book/project glyph
        g.setColor(new Color(255,255,255,220)); int bx = w/4, by = h/3; g.fillRect(bx, by, w/2, h/10); g.fillRect(bx, by + h/8, w/2, h/10);
        // pulsing halo
        int r = 10 + (int)(6*Math.abs(Math.sin(phase)));
        g.setColor(new Color(80,180,220, 90)); g.fillOval(w/2 - r, h/2 - r, r*2, r*2);
        g.dispose(); }
    public BufferedImage getImage(){ return img; }
}
