import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import models.User;

public class LoginFrame extends JFrame {
    private DBHelper db;
    private AnimatedBox animatedBox;

    public LoginFrame(DBHelper db) {
        super("Project Management - Login / Sign Up");
        this.db = db;
        init();
    }

    // Panel that draws an animated dragon which follows the cursor
    private class DragonPanel extends JPanel {
        private double tx = -200, ty = -200; // target
        private double x = -200, y = -200;   // current
        private java.util.List<double[]> trail = new java.util.ArrayList<>();
        private double wingPhase = 0;
        private javax.swing.Timer timer;

        public DragonPanel() {
            setBackground(Color.BLACK);
            // initialize trail
            for (int i = 0; i < 10; i++) trail.add(new double[]{x, y});
            timer = new javax.swing.Timer(30, e -> {
                // smooth follow
                x += (tx - x) * 0.18;
                y += (ty - y) * 0.18;
                // update trail
                trail.add(0, new double[]{x, y});
                if (trail.size() > 20) trail.remove(trail.size() - 1);
                wingPhase += 0.3;
                repaint();
            });
            timer.start();
            addHierarchyListener(ev -> {
                if ((ev.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing()) timer.stop();
            });
        }

        public void setMousePos(java.awt.Point p) {
            this.tx = p.x;
            this.ty = p.y;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // draw subtle background gradient
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0,0, Color.BLACK, 0, h, new Color(20,20,30));
            g2.setPaint(gp);
            g2.fillRect(0,0,w,h);

            // draw trail
            for (int i = trail.size()-1; i >= 0; i--) {
                double[] p = trail.get(i);
                float alpha = (float) (1.0 - (i/(double)trail.size()));
                int size = (int)(20 * (1.0 - i/(double)trail.size())) + 6;
                g2.setColor(new Color(100,180,255, (int)(alpha*180)));
                g2.fillOval((int)p[0]-size/2, (int)p[1]-size/2, size, size);
            }

            // draw glowing orb at the head of the trail (follow cursor)
            // concentric circles for glow
            int cx = (int) Math.round(x);
            int cy = (int) Math.round(y);
            for (int i = 8; i >= 1; i--) {
                float alpha = (float) (0.08 * i);
                int size = i * 6 + 6;
                g2.setColor(new Color(80, 200, 180, Math.min(255, (int)(alpha * 255))));
                g2.fillOval(cx - size/2, cy - size/2, size, size);
            }
            // small core
            g2.setColor(new Color(220, 255, 230));
            g2.fillOval(cx-6, cy-6, 12, 12);

            g2.dispose();
        }

        // dragon body removed; trail-only animation kept
    }

    // Animated box panel with rotating white border and glow
    private class AnimatedBox extends JPanel {
        private double angle = 0.0;
        private javax.swing.Timer timer;

        public AnimatedBox(LayoutManager lm) {
            super(lm);
            setOpaque(true);
            timer = new javax.swing.Timer(40, e -> {
                angle += Math.PI/180 * 4; // 4 degrees per tick
                repaint();
            });
            timer.start();
            // Stop timer when panel is removed
            addHierarchyListener(ev -> {
                if ((ev.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing()) {
                    timer.stop();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            int w = getWidth();
            int h = getHeight();

            // Draw faint glow background on edges
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int pad = 6;
            // Glow
            for (int i = 8; i >= 1; i--) {
                float alpha = (float) (0.04 * i);
                g2.setColor(new Color(1f,1f,1f, alpha));
                g2.setStroke(new BasicStroke(i));
                g2.drawRoundRect(pad - i, pad - i, w - (pad - i) * 2, h - (pad - i) * 2, 20, 20);
            }

            // Rotating white border arc
            g2.setStroke(new BasicStroke(3f));
            g2.setColor(Color.WHITE);
            int arcPad = 10;
            int arcW = w - arcPad*2;
            int arcH = h - arcPad*2;
            // Draw several arcs with rotation for effect
            for (int i=0;i<6;i++){
                double a = angle + i * Math.PI/3;
                int start = (int) Math.toDegrees(a) % 360;
                g2.drawArc(arcPad, arcPad, arcW, arcH, start, 40);
            }

            g2.dispose();
        }
    }

    private void init() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 420);
        setLocationRelativeTo(null);

    // Main background panel (black) with dragon animation
    DragonPanel bg = new DragonPanel();
    bg.setLayout(new GridBagLayout());

    // Center animated box with grey background
    JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(Color.LIGHT_GRAY);
        tabs.setForeground(Color.BLACK);
        tabs.add("Login", buildLoginPanel());
        tabs.add("Sign Up", buildSignupPanel());

    animatedBox = new AnimatedBox(new BorderLayout());
    animatedBox.setBackground(Color.DARK_GRAY);
    animatedBox.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
    animatedBox.add(tabs, BorderLayout.CENTER);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.weightx = 1; c.weighty = 1;
        bg.add(animatedBox, c);

        // track mouse movements so dragon follows cursor
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                // convert to bg coordinates
                java.awt.Point p = SwingUtilities.convertPoint(LoginFrame.this, e.getPoint(), bg);
                bg.setMousePos(p);
            }
            @Override
            public void mouseDragged(java.awt.event.MouseEvent e) {
                mouseMoved(e);
            }
        });

        add(bg);
    }

    private JPanel buildLoginPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.DARK_GRAY);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8,8,8,8);
        c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.EAST;
        JLabel userLbl = new JLabel("Username:"); userLbl.setForeground(Color.WHITE); p.add(userLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField userField = new JTextField(18); userField.setBackground(Color.LIGHT_GRAY); p.add(userField, c);

        c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.EAST; JLabel passLbl = new JLabel("Password:"); passLbl.setForeground(Color.WHITE); p.add(passLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JPasswordField passField = new JPasswordField(18); passField.setBackground(Color.LIGHT_GRAY); p.add(passField, c);

        c.gridx = 0; c.gridy = 2; c.gridwidth = 2; c.anchor = GridBagConstraints.CENTER;
        JButton loginBtn = new JButton("Login"); loginBtn.setBackground(new Color(30,144,255)); loginBtn.setForeground(Color.WHITE);
        p.add(loginBtn, c);

        loginBtn.addActionListener(e -> {
            String u = userField.getText().trim();
            String pw = new String(passField.getPassword());
            if (u.isEmpty() || pw.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter username and password.");
                return;
            }
            if (db.validateLogin(u, pw)) {
                User user = db.getUser(u);
                SwingUtilities.invokeLater(() -> {
                    DashboardFrame df = new DashboardFrame(db, user);
                    df.setVisible(true);
                });
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials.");
            }
        });

        return p;
    }

    private JPanel buildSignupPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.DARK_GRAY);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8,8,8,8);

        c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.EAST; JLabel userLbl = new JLabel("Username:"); userLbl.setForeground(Color.WHITE); p.add(userLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField userField = new JTextField(16); userField.setBackground(Color.LIGHT_GRAY); p.add(userField, c);

        c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.EAST; JLabel passLbl = new JLabel("Password:"); passLbl.setForeground(Color.WHITE); p.add(passLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JPasswordField passField = new JPasswordField(16); passField.setBackground(Color.LIGHT_GRAY); p.add(passField, c);

        c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.EAST; JLabel roleLbl = new JLabel("Role:"); roleLbl.setForeground(Color.WHITE); p.add(roleLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JComboBox<String> roleBox = new JComboBox<>(new String[]{"student","teacher","admin"}); roleBox.setBackground(Color.LIGHT_GRAY); p.add(roleBox, c);

        c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.EAST; JLabel deptLbl = new JLabel("Department:"); deptLbl.setForeground(Color.WHITE); p.add(deptLbl, c);
        c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField deptField = new JTextField(16); deptField.setBackground(Color.LIGHT_GRAY); p.add(deptField, c);

        c.gridx = 0; c.gridy = 4; c.gridwidth = 2; c.anchor = GridBagConstraints.CENTER;
        JButton signupBtn = new JButton("Sign Up"); signupBtn.setBackground(new Color(34,139,34)); signupBtn.setForeground(Color.WHITE); p.add(signupBtn, c);

        signupBtn.addActionListener(e -> {
            String u = userField.getText().trim();
            String pw = new String(passField.getPassword());
            String role = (String)roleBox.getSelectedItem();
            String dept = deptField.getText().trim();
            if (u.isEmpty() || pw.isEmpty() || dept.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
                return;
            }
            boolean ok = db.addUser(u, pw, role, dept);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Sign up successful. You can now log in.");
            } else {
                JOptionPane.showMessageDialog(this, "Username already exists.");
            }
        });

        return p;
    }
}
