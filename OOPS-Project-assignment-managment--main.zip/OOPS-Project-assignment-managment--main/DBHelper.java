import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import models.User;
import models.Project;
import models.Assignment;

public class DBHelper {
    private static final String USER_FILE = "data/users.ser";
    private static final String PROJECT_FILE = "data/projects.ser";
    private static final String ASSIGN_FILE = "data/assignments.ser";

    private Map<String, User> users = new HashMap<>();
    private Map<String, Project> projects = new HashMap<>();
    private List<Assignment> assignments = new ArrayList<>();
    // simple change listeners to notify UI when data changes
    private List<Runnable> changeListeners = new ArrayList<>();

    public void addChangeListener(Runnable r) { if (r != null) changeListeners.add(r); }

    private void notifyChangeListeners() {
        for (Runnable r : changeListeners) {
            try { r.run(); } catch (Exception ex) { /* ignore listener errors */ }
        }
    }

    public DBHelper() {
        loadAll();
    }

    private void loadAll() {
        users = (Map<String, User>) readObject(USER_FILE, new HashMap<String, User>());
        projects = (Map<String, Project>) readObject(PROJECT_FILE, new HashMap<String, Project>());
        assignments = (List<Assignment>) readObject(ASSIGN_FILE, new ArrayList<Assignment>());
    }

    @SuppressWarnings("unchecked")
    private <T> T readObject(String path, T def) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            return (T) ois.readObject();
        } catch (Exception e) {
            return def;
        }
    }

    private void writeObject(String path, Object obj) {
        try {
            File f = new File(path);
            f.getParentFile().mkdirs();
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
                oos.writeObject(obj);
            }
            // notify after successful write
            notifyChangeListeners();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addUser(String username, String password, String role, String department) {
        if (users.containsKey(username)) return false;
        String hash = hash(password);
        User u = new User(username, hash, role, department);
        users.put(username, u);
        writeObject(USER_FILE, users);
        return true;
    }

    public boolean updateUserProfile(String username, String prn, String phone, String division, String email, String groupId) {
        User u = users.get(username);
        if (u == null) return false;
        u.setPrn(prn); u.setPhone(phone); u.setDivision(division); u.setEmail(email); u.setGroupId(groupId);
        writeObject(USER_FILE, users);
        return true;
    }

    // assign marks by teacher/admin
    public boolean assignMarks(String projectId, String studentUsername, Integer marks) {
        for (Assignment a : assignments) {
            if (a.getProjectId().equals(projectId) && a.getStudentUsername().equalsIgnoreCase(studentUsername)) {
                a.setMarks(marks, java.time.LocalDate.now());
                writeObject(ASSIGN_FILE, assignments);
                return true;
            }
        }
        return false;
    }

    public List<User> getStudentsByDeptAndDiv(String department, String division) {
        List<User> out = new ArrayList<>();
        for (User u : users.values()) {
            if (u.getRole()!=null && u.getRole().equalsIgnoreCase("student") && u.getDepartment()!=null && u.getDepartment().equalsIgnoreCase(department)) {
                if (division==null || division.trim().isEmpty() || division.equalsIgnoreCase(u.getDivision())) out.add(u);
            }
        }
        return out;
    }

    public User getUser(String username) {
        return users.get(username);
    }

    // set a user's group id and persist
    public boolean setUserGroup(String username, String groupId) {
        User u = users.get(username);
        if (u == null) return false;
        u.setGroupId(groupId);
        writeObject(USER_FILE, users);
        return true;
    }

    public boolean validateLogin(String username, String password) {
        User u = users.get(username);
        if (u == null) return false;
        return u.getPasswordHash().equals(hash(password));
    }

    public void addProject(Project p) {
        projects.put(p.getId(), p);
        writeObject(PROJECT_FILE, projects);
    }

    public boolean setProjectGroupSize(String projectId, int groupSize) {
        Project p = projects.get(projectId);
        if (p == null) return false;
        p.setGroupSize(groupSize);
        writeObject(PROJECT_FILE, projects);
        return true;
    }

    public Collection<Project> getProjects() { return projects.values(); }

    public Project getProject(String id) { return projects.get(id); }

    public void assignProject(String projectId, String studentUsername) {
        // record assignment date as today
        assignments.add(new Assignment(projectId, studentUsername, java.time.LocalDate.now()));
        writeObject(ASSIGN_FILE, assignments);
    }

    // remove a specific assignment (admin only should call this)
    public boolean removeAssignment(String projectId, String studentUsername) {
        boolean removed = assignments.removeIf(a -> a.getProjectId().equals(projectId) && a.getStudentUsername().equalsIgnoreCase(studentUsername));
        if (removed) writeObject(ASSIGN_FILE, assignments);
        return removed;
    }

    // remove guide teacher from a project (sets guideTeacher to null)
    public boolean removeGuideFromProject(String projectId) {
        Project p = projects.get(projectId);
        if (p == null) return false;
        p.setGuideTeacher(null);
        writeObject(PROJECT_FILE, projects);
        return true;
    }

    // update editable fields of a project
    public boolean updateProject(String projectId, String newTitle, String newDesc, java.time.LocalDate newDue) {
        Project p = projects.get(projectId);
        if (p == null) return false;
        if (newTitle != null) p.setTitle(newTitle);
        if (newDesc != null) p.setDescription(newDesc);
        p.setDueDate(newDue);
        writeObject(PROJECT_FILE, projects);
        return true;
    }

    public List<Assignment> getAssignments() { return assignments; }

    public boolean submitAssignment(String projectId, String studentUsername, String link) {
        for (Assignment a : assignments) {
            if (a.getProjectId().equals(projectId) && a.getStudentUsername().equalsIgnoreCase(studentUsername)) {
                a.setSubmission(link, java.time.LocalDate.now());
                writeObject(ASSIGN_FILE, assignments);
                return true;
            }
        }
        return false;
    }

    public boolean submitAssignment(String projectId, String studentUsername, String link, String groupId, java.util.List<models.GroupMember> members) {
        for (Assignment a : assignments) {
            if (a.getProjectId().equals(projectId) && a.getStudentUsername().equalsIgnoreCase(studentUsername)) {
                a.setSubmission(link, java.time.LocalDate.now());
                a.setGroupId(groupId);
                a.setGroupMembers(members);
                writeObject(ASSIGN_FILE, assignments);
                return true;
            }
        }
        return false;
    }

    public java.util.List<User> getUsersByGroupId(String groupId) {
        java.util.List<User> out = new java.util.ArrayList<>();
        if (groupId == null) return out;
        for (User u : users.values()) {
            if (groupId.equals(u.getGroupId())) out.add(u);
        }
        return out;
    }

    public boolean unsubmitAssignment(String projectId, String studentUsername) {
        for (Assignment a : assignments) {
            if (a.getProjectId().equals(projectId) && a.getStudentUsername().equalsIgnoreCase(studentUsername)) {
                a.setSubmission(null, null);
                writeObject(ASSIGN_FILE, assignments);
                return true;
            }
        }
        return false;
    }

    public List<Assignment> getAssignmentsForStudent(String username) {
        List<Assignment> out = new ArrayList<>();
        for (Assignment a : assignments) if (a.getStudentUsername().equalsIgnoreCase(username)) out.add(a);
        return out;
    }

    private String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
