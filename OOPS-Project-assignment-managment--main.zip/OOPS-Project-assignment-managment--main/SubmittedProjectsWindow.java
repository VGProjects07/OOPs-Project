import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.awt.Desktop;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import models.User;

public class SubmittedProjectsWindow extends JFrame {
    private DBHelper db;
    private User user;

    public SubmittedProjectsWindow(DBHelper db, User user) {
        super("Submitted Projects"); this.db = db; this.user = user; init();
    }

    private void init() {
        setSize(620,420); setLocationRelativeTo(null); setMinimumSize(new Dimension(520,360));
        TrailPanel bg = new TrailPanel(); bg.setLayout(new GridBagLayout());
        JPanel card = new JPanel(new BorderLayout()); card.setOpaque(false); card.setPreferredSize(new Dimension(520,320));
    JPanel header = new JPanel(new BorderLayout()); header.setOpaque(false);
    JLabel hdr = new JLabel("Submitted Projects"); hdr.setForeground(Color.WHITE); hdr.setFont(hdr.getFont().deriveFont(Font.BOLD,16f));
    // place title on its own line to avoid overlapping with filters
    JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT)); topRow.setOpaque(false); topRow.add(hdr);
    header.add(topRow, BorderLayout.NORTH);

    // filter controls on their own row
    JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT)); filters.setOpaque(false);
        JComboBox<String> titleBox = new JComboBox<>(); JComboBox<String> divBox = new JComboBox<>(); JComboBox<String> deptBox = new JComboBox<>();
        titleBox.setBackground(new Color(60,60,60)); titleBox.setForeground(Color.WHITE);
        divBox.setBackground(new Color(60,60,60)); divBox.setForeground(Color.WHITE);
        deptBox.setBackground(new Color(60,60,60)); deptBox.setForeground(Color.WHITE);
        filters.add(new JLabel("Title:")); filters.add(titleBox);
        filters.add(new JLabel("Division:")); filters.add(divBox);
        filters.add(new JLabel("Dept:")); filters.add(deptBox);
        header.add(filters, BorderLayout.EAST);

        DefaultListModel<models.Assignment> lm = new DefaultListModel<>();
        JList<models.Assignment> jlist = new JList<>(lm);
        jlist.setBackground(new Color(60,60,60)); jlist.setForeground(Color.WHITE);
        jlist.setCellRenderer((list, value, index, isSelected, cellHasFocus) -> {
            models.Project p = db.getProject(value.getProjectId());
            String t = (p==null?"(deleted)":p.getTitle());
            JLabel lab = new JLabel(t + " — " + value.getStudentUsername() + (value.getSubmissionLink()==null?" (not submitted)":" (submitted)"));
            lab.setOpaque(true); lab.setForeground(Color.WHITE); lab.setBackground(isSelected?new Color(80,80,80):new Color(60,60,60)); lab.setBorder(BorderFactory.createEmptyBorder(6,8,6,8));
            return lab;
        });
        JScrollPane sc = new JScrollPane(jlist);

        card.add(header, BorderLayout.NORTH);
        card.add(sc, BorderLayout.CENTER);
        bg.add(card); add(bg);

    // prepare filter options based on visible assignments (admins see all; teachers see only their projects)
        Runnable prepareFilters = () -> {
            Set<String> titles = new TreeSet<>(); Set<String> divs = new TreeSet<>(); Set<String> depts = new TreeSet<>();
            titles.add("All"); divs.add("All"); depts.add("All");
            for (models.Assignment a : db.getAssignments()) {
                models.Project p = db.getProject(a.getProjectId());
                if (p==null) continue;
                // visibility: admin sees all. Teachers see projects they guide OR projects in their department
                if (user.getRole()!=null && user.getRole().equalsIgnoreCase("teacher")) {
                    boolean isGuide = user.getUsername()!=null && user.getUsername().equalsIgnoreCase(p.getGuideTeacher()==null?"":p.getGuideTeacher());
                    boolean sameDept = user.getDepartment()!=null && p.getDepartment()!=null && user.getDepartment().equalsIgnoreCase(p.getDepartment());
                    if (!isGuide && !sameDept) continue;
                }
                titles.add(p.getTitle()==null?"(untitled)":p.getTitle());
                models.User su = db.getUser(a.getStudentUsername());
                if (su!=null) { if (su.getDivision()!=null) divs.add(su.getDivision()); if (su.getDepartment()!=null) depts.add(su.getDepartment()); }
            }
            titleBox.removeAllItems(); for (String s : titles) titleBox.addItem(s);
            divBox.removeAllItems(); for (String s : divs) divBox.addItem(s);
            deptBox.removeAllItems(); for (String s : depts) deptBox.addItem(s);
        };

        // reload list based on filters
    JCheckBox onlySubmitted = new JCheckBox("Submitted"); onlySubmitted.setOpaque(false); onlySubmitted.setForeground(Color.WHITE);
        filters.add(onlySubmitted);

        Runnable reload = () -> {
            lm.clear();
            String selTitle = (String) titleBox.getSelectedItem();
            String selDiv = (String) divBox.getSelectedItem();
            String selDept = (String) deptBox.getSelectedItem();
            java.util.List<models.Assignment> submittedList = new java.util.ArrayList<>();
            java.util.List<models.Assignment> pendingList = new java.util.ArrayList<>();
            for (models.Assignment a : db.getAssignments()) {
                models.Project p = db.getProject(a.getProjectId());
                if (p==null) continue;
                // visibility check
                if (user.getRole()!=null && user.getRole().equalsIgnoreCase("teacher")) {
                    boolean isGuide = user.getUsername()!=null && user.getUsername().equalsIgnoreCase(p.getGuideTeacher()==null?"":p.getGuideTeacher());
                    boolean sameDept = user.getDepartment()!=null && p.getDepartment()!=null && user.getDepartment().equalsIgnoreCase(p.getDepartment());
                    if (!isGuide && !sameDept) continue;
                }
                models.User su = db.getUser(a.getStudentUsername());
                String studDiv = su==null?null:su.getDivision();
                String studDept = su==null?null:su.getDepartment();
                if (selTitle!=null && !selTitle.equals("All") && (p.getTitle()==null || !p.getTitle().equals(selTitle))) continue;
                if (selDiv!=null && !selDiv.equals("All") && (studDiv==null || !studDiv.equals(selDiv))) continue;
                if (selDept!=null && !selDept.equals("All") && (studDept==null || !studDept.equals(selDept))) continue;
                boolean submitted = a.getSubmissionLink()!=null && !a.getSubmissionLink().trim().isEmpty();
                if (onlySubmitted.isSelected()) {
                    if (submitted) submittedList.add(a);
                } else {
                    if (submitted) submittedList.add(a); else pendingList.add(a);
                }
            }
            // add submitted first, then pending
            for (models.Assignment a : submittedList) lm.addElement(a);
            for (models.Assignment a : pendingList) lm.addElement(a);
        };
    // default to showing only submitted for teachers
    if (user.getRole()!=null && user.getRole().equalsIgnoreCase("teacher")) onlySubmitted.setSelected(true);
    onlySubmitted.addItemListener(e -> { if (e.getStateChange()==ItemEvent.SELECTED || e.getStateChange()==ItemEvent.DESELECTED) reload.run(); });

    prepareFilters.run();
    // default to first item (All) to ensure reload shows everything initially
    if (titleBox.getItemCount() > 0) titleBox.setSelectedIndex(0);
    if (divBox.getItemCount() > 0) divBox.setSelectedIndex(0);
    if (deptBox.getItemCount() > 0) deptBox.setSelectedIndex(0);
    titleBox.addItemListener(e -> { if (e.getStateChange()==ItemEvent.SELECTED) reload.run(); });
    divBox.addItemListener(e -> { if (e.getStateChange()==ItemEvent.SELECTED) reload.run(); });
    deptBox.addItemListener(e -> { if (e.getStateChange()==ItemEvent.SELECTED) reload.run(); });
    // Add a refresh button so teacher/admin can force reload
    JButton refreshBtn = new JButton("Refresh"); refreshBtn.setBackground(new Color(60,60,60)); refreshBtn.setForeground(Color.WHITE);
    filters.add(refreshBtn);
    refreshBtn.addActionListener(ev -> { prepareFilters.run(); reload.run(); });
    reload.run();

        // click to view details
        jlist.addMouseListener(new MouseAdapter(){
            @Override public void mouseClicked(MouseEvent e) {
                int idx = jlist.locationToIndex(e.getPoint()); if (idx<0) return;
                models.Assignment a = lm.get(idx);
                models.Project p = db.getProject(a.getProjectId());
                models.User su = db.getUser(a.getStudentUsername());
                String title = p==null?"(deleted)":p.getTitle();
                String student = a.getStudentUsername();
                String prn = su==null?"N/A":(su.getPrn()==null?"N/A":su.getPrn());
                String div = su==null?"N/A":(su.getDivision()==null?"N/A":su.getDivision());
                String dept = su==null?"N/A":(su.getDepartment()==null?"N/A":su.getDepartment());
                String link = a.getSubmissionLink()==null?"(not submitted)":a.getSubmissionLink();
                String submitted = a.getSubmissionDate()==null?"N/A":a.getSubmissionDate().toString();
                String marks = a.getMarks()==null?"(not graded)":String.valueOf(a.getMarks());
                String marksDate = a.getMarksDate()==null?"N/A":a.getMarksDate().toString();
                StringBuilder sb = new StringBuilder();
                sb.append("<html><b>Project:</b> ").append(title).append("<br>");
                sb.append("<b>Student:</b> ").append(student).append("<br>");
                sb.append("<b>PRN:</b> ").append(prn).append("<br>");
                sb.append("<b>Division:</b> ").append(div).append("<br>");
                sb.append("<b>Department:</b> ").append(dept).append("<br>");
                sb.append("<b>Link:</b> ").append(link).append("<br>");
                sb.append("<b>Submitted:</b> ").append(submitted).append("<br>");
                sb.append("<b>Marks:</b> ").append(marks).append("<br>");
                sb.append("<b>Marks Date:</b> ").append(marksDate).append("</html>");

                // show group member details if present
                java.util.List<models.GroupMember> g = a.getGroupMembers();
                if (g != null && !g.isEmpty()) {
                    sb.append("<hr><b>Group Members:</b><br>");
                    for (models.GroupMember gm : g) {
                        sb.append("Name: ").append(gm.getName()==null?"N/A":gm.getName()).append(" — PRN: ").append(gm.getPrn()==null?"N/A":gm.getPrn()).append(" — Dept: ").append(gm.getDepartment()==null?"N/A":gm.getDepartment()).append(" — Div: ").append(gm.getDivision()==null?"N/A":gm.getDivision()).append("<br>");
                    }
                    sb.append("</html>");
                }

                // Teachers can only view submissions for their projects (already filtered). Admins can view all.
                Object[] opts = {"Close", "Open Link"};
                int sel = JOptionPane.showOptionDialog(SubmittedProjectsWindow.this, sb.toString(), "Submission Details", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
                if (sel==1 && a.getSubmissionLink()!=null && !a.getSubmissionLink().trim().isEmpty()) {
                    try {
                        if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(new URI(a.getSubmissionLink()));
                    } catch (java.net.URISyntaxException | java.io.IOException ex) {
                        JOptionPane.showMessageDialog(SubmittedProjectsWindow.this, "Failed to open link.");
                    }
                }
            }
        });

        // refresh on focus
        addWindowFocusListener(new WindowAdapter(){ @Override public void windowGainedFocus(WindowEvent e){ prepareFilters.run(); reload.run(); } });

        // register for DB change events to auto-refresh when data changes (submit/unsubmit/assign)
        db.addChangeListener(() -> {
            SwingUtilities.invokeLater(() -> { try { prepareFilters.run(); reload.run(); } catch (Exception ex) { /* ignore */ } });
        });
    }
}
