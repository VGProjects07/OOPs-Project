import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import models.User;

public class ViewAssignmentsWindow extends JFrame {
    private DBHelper db;
    private User user;

    public ViewAssignmentsWindow(DBHelper db, User user) { super("View Assignments"); this.db=db; this.user=user; init(); }

    private void init() {
        setSize(620,420); setLocationRelativeTo(null); setMinimumSize(new Dimension(520,360));
        TrailPanel bg = new TrailPanel(); bg.setLayout(new GridBagLayout());
        JPanel card = new RoundedPanel(); card.setLayout(new BorderLayout(10,10)); card.setOpaque(false); card.setPreferredSize(new Dimension(520,320));

    JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT,12,8)); header.setOpaque(false);
    PulsingIcon picon = new PulsingIcon(48,48);
    JLabel iconLabel = new JLabel(new ImageIcon(picon.getImage()));
    Timer iconTimer = new Timer(90, ev -> { picon.pulse(); iconLabel.setIcon(new ImageIcon(picon.getImage())); });
    iconTimer.start();
    header.add(iconLabel);
    JLabel title = new JLabel("Assignments"); title.setForeground(Color.WHITE); title.setFont(title.getFont().deriveFont(Font.BOLD,18f)); header.add(title);

        // Build either a teacher/admin table view or a student list view
        boolean isTeacherLike = user.getRole() != null && (user.getRole().equalsIgnoreCase("teacher") || user.getRole().equalsIgnoreCase("admin"));

        JScrollPane content;
        if (isTeacherLike) {
            // Table columns: Project, Student, PRN, Group ID, Division, Submission Link, Submitted Date, Marks
            String[] cols = new String[]{"Project", "Student", "PRN", "Group ID", "Division", "Submission Link", "Submitted Date", "Marks"};
            javax.swing.table.DefaultTableModel tm = new javax.swing.table.DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int row, int column) { return false; }
            };
            JTable table = new JTable(tm);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            table.setBackground(new Color(60,60,60)); table.setForeground(Color.WHITE);

            // populate rows
            Runnable reloadTable = () -> {
                tm.setRowCount(0);
                for (models.Assignment a : db.getAssignments()) {
                    models.Project p = db.getProject(a.getProjectId());
                    if (p == null) continue;
                    // teachers see projects they guide OR in their department; admins see all
                    if (user.getRole()!=null && user.getRole().equalsIgnoreCase("teacher")) {
                        boolean isGuide = user.getUsername()!=null && user.getUsername().equalsIgnoreCase(p.getGuideTeacher()==null?"":p.getGuideTeacher());
                        boolean sameDept = user.getDepartment()!=null && p.getDepartment()!=null && user.getDepartment().equalsIgnoreCase(p.getDepartment());
                        if (!isGuide && !sameDept) continue;
                    }
                    models.User su = db.getUser(a.getStudentUsername());
                    String prn = su==null?"N/A":(su.getPrn()==null?"N/A":su.getPrn());
                    String gid = su==null?"N/A":(su.getGroupId()==null?"N/A":su.getGroupId());
                    String div = su==null?"N/A":(su.getDivision()==null?"N/A":su.getDivision());
                    String link = a.getSubmissionLink()==null?"":a.getSubmissionLink();
                    String sdate = a.getSubmissionDate()==null?"":(a.getSubmissionDate().toString());
                    String marks = a.getMarks()==null?"":String.valueOf(a.getMarks());
                    tm.addRow(new Object[]{p.getTitle(), a.getStudentUsername(), prn, gid, div, link, sdate, marks});
                }
            };
            reloadTable.run();

            // detail panel for selected row: open link, enter marks
            JPanel detail = new JPanel(new FlowLayout(FlowLayout.LEFT)); detail.setOpaque(false);
            JLabel selLbl = new JLabel("Selected: "); selLbl.setForeground(Color.WHITE);
            JTextField marksF = new JTextField(6);
            JButton saveMarks = new JButton("Save Marks");
            JButton openLink = new JButton("Open Link");
            detail.add(selLbl); detail.add(new JLabel("Marks:")); detail.add(marksF); detail.add(saveMarks); detail.add(openLink);

            // selection listener
            table.getSelectionModel().addListSelectionListener(ev -> {
                int r = table.getSelectedRow();
                if (r < 0) { selLbl.setText("Selected: "); marksF.setText(""); return; }
                String projTitle = (String) table.getValueAt(r, 0);
                String student = (String) table.getValueAt(r, 1);
                selLbl.setText("Selected: " + projTitle + " — " + student);
                String existing = (String) table.getValueAt(r, 7);
                marksF.setText(existing==null?"":existing);
            });

            saveMarks.addActionListener(e -> {
                int r = table.getSelectedRow(); if (r<0) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Select a row first."); return; }
                String projTitle = (String) table.getValueAt(r, 0);
                String student = (String) table.getValueAt(r, 1);
                // find project id by title (first match)
                String projId = null;
                for (models.Project p : db.getProjects()) if (p.getTitle()!=null && p.getTitle().equals(projTitle)) { projId = p.getId(); break; }
                if (projId==null) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Project not found."); return; }
                String mtxt = marksF.getText().trim(); Integer m = null; try { if (!mtxt.isEmpty()) m = Integer.parseInt(mtxt); } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Marks must be an integer."); return; }
                boolean ok = db.assignMarks(projId, student, m);
                if (ok) {
                    JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Marks saved.");
                    reloadTable.run();
                } else JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Failed to save marks.");
            });

            openLink.addActionListener(e -> {
                int r = table.getSelectedRow(); if (r<0) return;
                String link = (String) table.getValueAt(r, 5);
                if (link==null || link.trim().isEmpty()) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "No submission link."); return; }
                try { if (java.awt.Desktop.isDesktopSupported()) java.awt.Desktop.getDesktop().browse(new java.net.URI(link)); } catch (Exception ex) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Failed to open link."); }
            });

            content = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            content.setBorder(BorderFactory.createEmptyBorder()); content.setOpaque(false); content.getViewport().setOpaque(false);
            card.add(header, BorderLayout.NORTH);
            card.add(content, BorderLayout.CENTER);
            card.add(detail, BorderLayout.SOUTH);

            // register DB change listener to refresh table
            db.addChangeListener(() -> SwingUtilities.invokeLater(reloadTable));
        } else {
            // student view (existing list UI)
            DefaultListModel<models.Assignment> listModel = new DefaultListModel<>();
            JComboBox<String> filterBox = new JComboBox<>(new String[]{"All", "Submitted", "Not Submitted"});
            filterBox.setBackground(new Color(60,60,60)); filterBox.setForeground(Color.WHITE);
            JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT)); controls.setOpaque(false);
            controls.add(new JLabel("Filter:")); controls.add(filterBox);
            header.add(controls);

            Runnable reloadList = () -> {
                String filt = (String) filterBox.getSelectedItem();
                listModel.clear();
                for (models.Assignment a : db.getAssignments()) {
                    models.Project p = db.getProject(a.getProjectId());
                    if (p == null) continue;
                    if (!p.getDepartment().equalsIgnoreCase(user.getDepartment())) continue;
                    boolean submitted = a.getSubmissionLink() != null && !a.getSubmissionLink().trim().isEmpty();
                    if ("Submitted".equalsIgnoreCase(filt) && !submitted) continue;
                    if ("Not Submitted".equalsIgnoreCase(filt) && submitted) continue;
                    listModel.addElement(a);
                }
            };
            filterBox.addItemListener(ev -> { if (ev.getStateChange() == ItemEvent.SELECTED) reloadList.run(); });
            reloadList.run();

            JList<models.Assignment> list = new JList<>(listModel);
            list.setCellRenderer(new ListCellRenderer<models.Assignment>() {
                private final JPanel panel = new JPanel(new BorderLayout());
                private final JLabel lbl = new JLabel();
                @Override
                public Component getListCellRendererComponent(JList<? extends models.Assignment> list, models.Assignment value, int index, boolean isSelected, boolean cellHasFocus) {
                    models.Project p = db.getProject(value.getProjectId());
                    String title = (p==null)?"(deleted project)":p.getTitle();
                    lbl.setText("" + title + "  -  " + value.getStudentUsername());
                    lbl.setForeground(Color.WHITE);
                    panel.setOpaque(true);
                    panel.setBackground(isSelected ? new Color(80,80,80) : new Color(60,60,60));
                    lbl.setBorder(BorderFactory.createEmptyBorder(6,8,6,8));
                    panel.removeAll(); panel.add(lbl, BorderLayout.CENTER);
                    return panel;
                }
            });
            list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            list.setBackground(new Color(60,60,60));

            // Open details when an item is clicked (student behaviors kept)
            list.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int idx = list.locationToIndex(e.getPoint());
                    if (idx >= 0) {
                        models.Assignment a = listModel.get(idx);
                        models.Project p = db.getProject(a.getProjectId());
                        String title = (p==null)?"(deleted)":p.getTitle();
                        String desc = (p==null || p.getDescription()==null)?"N/A":p.getDescription();
                        String due = (p==null || p.getDueDate()==null)?"N/A":p.getDueDate().toString();
                        String assigned = (a.getAssignedDate()==null)?"N/A":a.getAssignedDate().toString();
                        String msg = "<html><b>Title:</b> " + title + "<br><br><b>Description:</b><br>" + desc.replaceAll("\n","<br>") + "<br><br><b>Due Date:</b> " + due + "<br><br><b>Assigned Date:</b> " + assigned + "</html>";
                        // If student and this assignment belongs to them, allow submit
                        if (user.getRole()!=null && user.getRole().equalsIgnoreCase("student") && a.getStudentUsername().equalsIgnoreCase(user.getUsername())) {
                            boolean submitted = a.getSubmissionLink() != null && !a.getSubmissionLink().trim().isEmpty();
                            Object[] opts = submitted ? new Object[]{"OK", "Project Submitted"} : new Object[]{"OK", "Submit Project"};
                            int s = JOptionPane.showOptionDialog(ViewAssignmentsWindow.this, msg, "Assignment Details", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opts, opts[0]);
                            if (s == 1) {
                                if (!submitted) {
                                    // If project has groups, show detailed group member form
                                    int gsize = 1;
                                    if (p != null) gsize = p.getGroupSize();
                                    if (gsize <= 1) {
                                        String link = JOptionPane.showInputDialog(ViewAssignmentsWindow.this, "Enter project drive link (URL):");
                                        if (link==null || link.trim().isEmpty()) return;
                                        boolean ok = db.submitAssignment(a.getProjectId(), a.getStudentUsername(), link.trim());
                                        if (ok) JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Submitted successfully."); else JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Submission failed.");
                                    } else {
                                        // collect group members: try to find users with same groupId
                                        String gid = null;
                                        models.User me = db.getUser(user.getUsername());
                                        if (me != null) gid = me.getGroupId();
                                        java.util.List<models.User> membersUsers = new java.util.ArrayList<>();
                                        if (gid != null) membersUsers = db.getUsersByGroupId(gid);
                                        // ensure list has gsize entries; if fewer, pad with nulls
                                        while (membersUsers.size() < gsize) membersUsers.add(null);

                                        // build form
                                        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(new Color(40,40,45));
                                        GridBagConstraints fc = new GridBagConstraints(); fc.insets = new Insets(6,6,6,6);
                                        fc.gridx = 0; fc.gridy = 0; form.add(new JLabel("Group ID (if assigned):"), fc);
                                        JTextField gidF = new JTextField(12); fc.gridx = 1; form.add(gidF, fc);
                                        JButton loadBtn = new JButton("Load Members"); fc.gridx = 2; form.add(loadBtn, fc);
                                        fc.gridy++; fc.gridx = 0; form.add(new JLabel("Submission Link:"), fc);
                                        JTextField linkF = new JTextField(30); fc.gridx = 1; form.add(linkF, fc);
                                        java.util.List<JTextField> nameFs = new java.util.ArrayList<>();
                                        java.util.List<JTextField> prnFs = new java.util.ArrayList<>();
                                        java.util.List<JTextField> deptFs = new java.util.ArrayList<>();
                                        java.util.List<JTextField> divFs = new java.util.ArrayList<>();
                                        for (int i = 0; i < gsize; i++) {
                                            models.User mu = membersUsers.get(i);
                                            fc.gridy++; fc.gridx = 0; form.add(new JLabel("Member " + (i+1) + " Name:"), fc);
                                            JTextField n = new JTextField(mu==null?"":mu.getUsername(), 18); fc.gridx = 1; form.add(n, fc);
                                            fc.gridy++; fc.gridx = 0; form.add(new JLabel("PRN:"), fc);
                                            JTextField pr = new JTextField(mu==null?"":(mu.getPrn()==null?"":mu.getPrn()), 12); fc.gridx = 1; form.add(pr, fc);
                                            fc.gridy++; fc.gridx = 0; form.add(new JLabel("Department:"), fc);
                                            JTextField dept = new JTextField(mu==null?"":(mu.getDepartment()==null?"":mu.getDepartment()), 12); fc.gridx = 1; form.add(dept, fc);
                                            fc.gridy++; fc.gridx = 0; form.add(new JLabel("Division:"), fc);
                                            JTextField dv = new JTextField(mu==null?"":(mu.getDivision()==null?"":mu.getDivision()), 8); fc.gridx = 1; form.add(dv, fc);
                                            nameFs.add(n); prnFs.add(pr); deptFs.add(dept); divFs.add(dv);
                                        }

                                        // make gsize effectively final for lambda
                                        final int finalGsize = gsize;
                                        // wire load button to populate member fields from entered group id
                                        loadBtn.addActionListener(ev -> {
                                            String entered = gidF.getText().trim();
                                            if (entered.isEmpty()) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Enter a Group ID to load members."); return; }
                                            java.util.List<models.User> loaded = db.getUsersByGroupId(entered);
                                            if (loaded.isEmpty()) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "No users found for that Group ID."); return; }
                                            // fill fields up to finalGsize
                                            for (int k = 0; k < finalGsize; k++) {
                                                models.User mu2 = k < loaded.size() ? loaded.get(k) : null;
                                                nameFs.get(k).setText(mu2==null?"":mu2.getUsername());
                                                prnFs.get(k).setText(mu2==null?"":(mu2.getPrn()==null?"":mu2.getPrn()));
                                                deptFs.get(k).setText(mu2==null?"":(mu2.getDepartment()==null?"":mu2.getDepartment()));
                                                divFs.get(k).setText(mu2==null?"":(mu2.getDivision()==null?"":mu2.getDivision()));
                                            }
                                        });

                                        int okk = JOptionPane.showConfirmDialog(ViewAssignmentsWindow.this, new JScrollPane(form), "Submit Project and group details", JOptionPane.OK_CANCEL_OPTION);
                                        if (okk == JOptionPane.OK_OPTION) {
                                            String link = linkF.getText().trim();
                                            if (link.isEmpty()) { JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Please enter submission link."); return; }
                                            String enteredGid = gidF.getText().trim();
                                            java.util.List<models.GroupMember> gm = new java.util.ArrayList<>();
                                            for (int i = 0; i < gsize; i++) {
                                                String nm = nameFs.get(i).getText().trim();
                                                String prn = prnFs.get(i).getText().trim();
                                                String deptv = deptFs.get(i).getText().trim();
                                                String divv = divFs.get(i).getText().trim();
                                                gm.add(new models.GroupMember(nm, prn, deptv, divv));
                                            }
                                            boolean ok2 = db.submitAssignment(a.getProjectId(), a.getStudentUsername(), link, enteredGid.isEmpty()?null:enteredGid, gm);
                                            if (ok2) JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Submitted successfully."); else JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Submission failed.");
                                        }
                                    }
                                } else {
                                    int yn = JOptionPane.showConfirmDialog(ViewAssignmentsWindow.this, "Unsubmit project? This will delete your submission.", "Unsubmit", JOptionPane.YES_NO_OPTION);
                                    if (yn == JOptionPane.YES_OPTION) {
                                        boolean ok = db.unsubmitAssignment(a.getProjectId(), a.getStudentUsername());
                                        if (ok) {
                                            JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Submission removed.");
                                            listModel.setElementAt(a, idx); // trigger repaint
                                        } else JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, "Failed to remove submission.");
                                    }
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(ViewAssignmentsWindow.this, msg, "Assignment Details", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            });

            content = new JScrollPane(list, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            content.setBorder(BorderFactory.createEmptyBorder()); content.setOpaque(false); content.getViewport().setOpaque(false);
            // register DB change listener
            db.addChangeListener(() -> SwingUtilities.invokeLater(reloadList));
        }

        card.add(header, BorderLayout.NORTH); card.add(content, BorderLayout.CENTER);
        JScrollPane cs = new JScrollPane(card, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cs.setOpaque(false); cs.getViewport().setOpaque(false); cs.setBorder(BorderFactory.createEmptyBorder()); cs.setPreferredSize(new Dimension(540,340));
    bg.add(cs); add(bg);
    addWindowListener(new WindowAdapter() { @Override public void windowClosed(WindowEvent e) { iconTimer.stop(); } });
    // auto-refresh is registered per-view above (table or list)
    }

    private static class RoundedPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0,0, new Color(35,35,40,220), 0, h, new Color(22,22,26,200));
            g2.setPaint(gp);
            g2.fillRoundRect(0,0,w,h,20,20);
            g2.setColor(new Color(255,255,255,20));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0,0,w-1,h-1,20,20);
            g2.dispose();
        }
    }
}
