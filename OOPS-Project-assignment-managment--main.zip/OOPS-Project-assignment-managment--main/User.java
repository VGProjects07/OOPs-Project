package models;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private String username;
    private String passwordHash;
    private String role; // student, teacher, admin
    private String department;
    // optional profile fields (students fill these)
    private String prn;
    private String groupId;
    private String phone;
    private String division;
    private String email;

    public User(String username, String passwordHash, String role, String department) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
        this.department = department;
    }

    // profile setters/getters
    public String getPrn() { return prn; }
    public void setPrn(String prn) { this.prn = prn; }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDivision() { return division; }
    public void setDivision(String division) { this.division = division; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getRole() {
        return role;
    }

    public String getDepartment() {
        return department;
    }
}
