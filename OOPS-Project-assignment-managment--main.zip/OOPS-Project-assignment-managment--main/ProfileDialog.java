import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import models.User;

public class ProfileDialog extends JDialog {
    private DBHelper db;
    private User user;

    public ProfileDialog(JFrame owner, DBHelper db, User user) {
        super(owner, "Profile - " + user.getUsername(), true);
        this.db = db; this.user = user;
        init();
    }

    private void init() {
        setSize(420,320); setLocationRelativeTo(getOwner()); setLayout(new BorderLayout());
        JPanel p = new JPanel(new GridBagLayout()); p.setBackground(new Color(40,40,45));
        GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(8,8,8,8);
        c.gridx=0; c.gridy=0; c.anchor = GridBagConstraints.EAST; JLabel nameL = new JLabel("Username:"); nameL.setForeground(Color.WHITE); p.add(nameL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JLabel nameV = new JLabel(user.getUsername()); nameV.setForeground(Color.WHITE); p.add(nameV, c);

        c.gridx=0; c.gridy=1; c.anchor=GridBagConstraints.EAST; JLabel deptL = new JLabel("Department:"); deptL.setForeground(Color.WHITE); p.add(deptL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JLabel deptV = new JLabel(user.getDepartment()); deptV.setForeground(Color.WHITE); p.add(deptV, c);

    JTextField prnF = new JTextField(18);
    JTextField divF = new JTextField(8);
    JTextField groupF = new JTextField(12);
        boolean isStudent = user.getRole()!=null && user.getRole().equalsIgnoreCase("student");
        if (isStudent) {
            c.gridx=0; c.gridy=2; c.anchor=GridBagConstraints.EAST; JLabel prnL = new JLabel("PRN No:"); prnL.setForeground(Color.WHITE); p.add(prnL, c);
            c.gridx=1; c.anchor=GridBagConstraints.WEST; prnF.setText(user.getPrn()==null?"":user.getPrn()); prnF.setBackground(new Color(60,60,60)); prnF.setForeground(Color.WHITE); p.add(prnF, c);

            c.gridx=0; c.gridy=3; c.anchor=GridBagConstraints.EAST; JLabel divL = new JLabel("Division:"); divL.setForeground(Color.WHITE); p.add(divL, c);
            c.gridx=1; c.anchor=GridBagConstraints.WEST; divF.setText(user.getDivision()==null?"":user.getDivision()); divF.setBackground(new Color(60,60,60)); divF.setForeground(Color.WHITE); p.add(divF, c);
            c.gridx=0; c.gridy=4; c.anchor=GridBagConstraints.EAST; JLabel groupL = new JLabel("Group ID:"); groupL.setForeground(Color.WHITE); p.add(groupL, c);
            c.gridx=1; c.anchor=GridBagConstraints.WEST; groupF.setText(user.getGroupId()==null?"":user.getGroupId()); groupF.setBackground(new Color(60,60,60)); groupF.setForeground(Color.WHITE); p.add(groupF, c);
        }

        c.gridx=0; c.gridy=4; c.anchor=GridBagConstraints.EAST; JLabel phoneL = new JLabel("Phone:"); phoneL.setForeground(Color.WHITE); p.add(phoneL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField phoneF = new JTextField(user.getPhone()==null?"":user.getPhone(), 12); phoneF.setBackground(new Color(60,60,60)); phoneF.setForeground(Color.WHITE); p.add(phoneF, c);

        c.gridx=0; c.gridy=5; c.anchor=GridBagConstraints.EAST; JLabel emailL = new JLabel("Email:"); emailL.setForeground(Color.WHITE); p.add(emailL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField emailF = new JTextField(user.getEmail()==null?"":user.getEmail(), 18); emailF.setBackground(new Color(60,60,60)); emailF.setForeground(Color.WHITE); p.add(emailF, c);

        JPanel actions = new JPanel(new BorderLayout()); actions.setOpaque(false);
        JPanel rightActions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); rightActions.setOpaque(false);
        JPanel leftActions = new JPanel(new FlowLayout(FlowLayout.LEFT)); leftActions.setOpaque(false);
        JButton save = new JButton("Save"); save.addActionListener(e -> {
            // Only update prn/div/group for students
            String prn = isStudent ? prnF.getText().trim() : user.getPrn();
            String div = isStudent ? divF.getText().trim() : user.getDivision();
            String gid = isStudent ? groupF.getText().trim() : user.getGroupId();
            db.updateUserProfile(user.getUsername(), prn, phoneF.getText().trim(), div, emailF.getText().trim(), gid);
            JOptionPane.showMessageDialog(this, "Profile saved.");
            dispose();
        });
        JButton close = new JButton("Close"); close.addActionListener(e -> dispose());
        JButton logout = new JButton("Logout"); logout.addActionListener(e -> {
            int ok = JOptionPane.showConfirmDialog(this, "Logout now?", "Logout", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                new LoginFrame(db).setVisible(true);
                // close owner (dashboard) as well
                if (getOwner() instanceof JFrame) ((JFrame)getOwner()).dispose();
                dispose();
            }
        });

        leftActions.add(logout);
        rightActions.add(save); rightActions.add(close);
        actions.add(leftActions, BorderLayout.WEST);
        actions.add(rightActions, BorderLayout.EAST);

        add(p, BorderLayout.CENTER);
        add(actions, BorderLayout.SOUTH);
    }
}
