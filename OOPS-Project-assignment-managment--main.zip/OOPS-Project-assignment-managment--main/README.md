# Project Management Java App

Simple Java Swing app with sign up / login and a dashboard for adding/assigning/viewing projects per department.

How to compile and run (Windows PowerShell):

1. Open PowerShell and change to project folder:

```powershell
cd C:\Users\athar\OneDrive\Desktop\oops_project
```

2. Compile:

```powershell
javac -d out -sourcepath src src\Main.java src\LoginFrame.java src\DashboardFrame.java src\DBHelper.java src\models\*.java
```

3. Run:

```powershell
java -cp out Main
```

Data files will be stored under `data/` inside the project folder.

Notes:
- This uses simple file-based serialization; do not use for production.
- Passwords are stored as SHA-256 hashes.
