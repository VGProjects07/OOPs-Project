import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import models.User;
import models.Project;
import java.util.ArrayList;
import java.util.List;

public class DashboardFrame extends JFrame {
    private DBHelper db;
    private User user;

    public DashboardFrame(DBHelper db, User user) {
        super("Dashboard - " + user.getUsername());
        this.db = db;
        this.user = user;
        init();
    }

    private void init() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
    JPanel top = new JPanel(new BorderLayout());
    top.setBackground(Color.DARK_GRAY);
    JLabel info = new JLabel("Logged in as: " + user.getUsername() + " (" + user.getRole() + ") Dept: " + user.getDepartment());
    info.setForeground(Color.WHITE);
    JPanel leftTop = new JPanel(new FlowLayout(FlowLayout.LEFT)); leftTop.setOpaque(false); leftTop.add(info);
    // profile button on right
    JButton profileBtn = new JButton(user.getUsername()); profileBtn.setBackground(Color.GRAY); profileBtn.setForeground(Color.WHITE);
    profileBtn.addActionListener(e -> new ProfileDialog(this, db, user).setVisible(true));
    JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT)); rightTop.setOpaque(false); rightTop.add(profileBtn);
    top.add(leftTop, BorderLayout.WEST);
    top.add(rightTop, BorderLayout.EAST);

        JPanel buttons = new JPanel(new GridLayout(1,5,8,8));
        buttons.setBackground(Color.BLACK);
    JButton addProj = new JButton("Add Project");
    JButton assignProj = new JButton("Assign Project");
    JButton viewGuide = new JButton("View Guide Teacher");
    JButton viewProj = new JButton("View Project Details");
    JButton submitProj = new JButton("Submitted Projects");
    // create simple icons
    int ic = 20;
    java.awt.image.BufferedImage addI = new java.awt.image.BufferedImage(ic, ic, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    java.awt.Graphics2D g = addI.createGraphics(); g.setColor(new Color(28,160,100)); g.fillRect(0,0,ic,ic); g.setColor(Color.WHITE); g.fillRect(4,8,12,4); g.fillRect(4,4,4,12); g.dispose();
    java.awt.image.BufferedImage assignI = new java.awt.image.BufferedImage(ic, ic, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    g = assignI.createGraphics(); g.setColor(new Color(30,144,255)); g.fillOval(0,0,ic,ic); g.setColor(Color.WHITE); g.fillRect(5,9,10,2); g.dispose();
    java.awt.image.BufferedImage guideI = new java.awt.image.BufferedImage(ic, ic, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    g = guideI.createGraphics(); g.setColor(new Color(200,120,30)); g.fillRoundRect(0,0,ic,ic,6,6); g.setColor(Color.WHITE); g.fillRect(4,6,12,3); g.dispose();
    java.awt.image.BufferedImage viewI = new java.awt.image.BufferedImage(ic, ic, java.awt.image.BufferedImage.TYPE_INT_ARGB);
    g = viewI.createGraphics(); g.setColor(new Color(120,90,200)); g.fillOval(0,0,ic,ic); g.setColor(Color.WHITE); g.fillOval(5,5,10,10); g.dispose();
    addProj.setIcon(new ImageIcon(addI)); assignProj.setIcon(new ImageIcon(assignI)); viewGuide.setIcon(new ImageIcon(guideI)); viewProj.setIcon(new ImageIcon(viewI)); submitProj.setIcon(new ImageIcon(viewI));
        // style buttons
        for (JButton b : new JButton[]{addProj, assignProj, viewGuide, viewProj, submitProj}) {
            b.setBackground(Color.DARK_GRAY); b.setForeground(Color.WHITE);
        }

        // Restrict Add/Assign to admins only (disable for students and teachers)
        if (user.getRole() == null || !user.getRole().equalsIgnoreCase("admin")) {
            addProj.setEnabled(false);
            assignProj.setEnabled(false);
            addProj.setToolTipText("Only admins can add projects");
            assignProj.setToolTipText("Only admins can assign projects");
        }

    buttons.add(addProj); buttons.add(assignProj); buttons.add(viewGuide); buttons.add(viewProj); buttons.add(submitProj);

    addProj.addActionListener(e -> new AddProjectWindow(db, user).setVisible(true));
    assignProj.addActionListener(e -> new AssignProjectWindow(db, user).setVisible(true));
        viewGuide.addActionListener(e -> new ViewGuideWindow(db, user).setVisible(true));
        viewProj.addActionListener(e -> new ViewAssignmentsWindow(db, user).setVisible(true));
        // Open student's submitted projects view
        submitProj.addActionListener(e -> {
            new SubmittedProjectsWindow(db, user).setVisible(true);
        });

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(top, BorderLayout.NORTH);
        // embed trail panel behind buttons
        TrailPanel tp = new TrailPanel();
        tp.setLayout(new BorderLayout());
        tp.add(buttons, BorderLayout.CENTER);
        getContentPane().add(tp, BorderLayout.CENTER);
    }

    private void onAddProject() {
        if (!"admin".equalsIgnoreCase(user.getRole())) {
            JOptionPane.showMessageDialog(this, "Only admins can add projects.");
            return;
        }
        JTextField idF = new JTextField();
        JTextField titleF = new JTextField();
        JTextField descF = new JTextField();
        JTextField deptF = new JTextField(user.getDepartment());
        JTextField guideF = new JTextField(user.getUsername());
        Object[] fields = {"ID:", idF, "Title:", titleF, "Description:", descF, "Department:", deptF, "Guide Teacher:", guideF};
        int ok = JOptionPane.showConfirmDialog(this, fields, "Add Project", JOptionPane.OK_CANCEL_OPTION);
        if (ok == JOptionPane.OK_OPTION) {
            Project p = new Project(idF.getText().trim(), titleF.getText().trim(), descF.getText().trim(), deptF.getText().trim(), guideF.getText().trim());
            db.addProject(p);
            JOptionPane.showMessageDialog(this, "Project added.");
        }
    }

    private void onAssignProject() {
        if (!"admin".equalsIgnoreCase(user.getRole())) {
            JOptionPane.showMessageDialog(this, "Only admins can assign projects.");
            return;
        }
        // list projects for department
    java.util.List<Project> list = new ArrayList<>();
        for (Project p : db.getProjects()) if (p.getDepartment().equalsIgnoreCase(user.getDepartment())) list.add(p);
        if (list.isEmpty()) { JOptionPane.showMessageDialog(this, "No projects for your department."); return; }
        String[] ids = list.stream().map(p -> p.getId() + " - " + p.getTitle()).toArray(String[]::new);
        String pick = (String) JOptionPane.showInputDialog(this, "Select project:", "Assign", JOptionPane.PLAIN_MESSAGE, null, ids, ids[0]);
        if (pick == null) return;
        String projId = pick.split(" - ")[0];
        String student = JOptionPane.showInputDialog(this, "Enter student username to assign:");
        if (student == null || student.trim().isEmpty()) return;
        db.assignProject(projId, student.trim());
        JOptionPane.showMessageDialog(this, "Assigned.");
    }

    private void onViewGuide() {
        StringBuilder sb = new StringBuilder();
        for (Project p : db.getProjects()) {
            if (p.getDepartment().equalsIgnoreCase(user.getDepartment())) {
                sb.append(p.getTitle()).append(" - ").append(p.getGuideTeacher()).append("\n");
            }
        }
        JTextArea ta = new JTextArea(sb.length()==0?"No projects":""+sb.toString());
        ta.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(ta), "Guide Teachers", JOptionPane.PLAIN_MESSAGE);
    }

    private void onViewProjects() {
        StringBuilder sb = new StringBuilder();
        for (Project p : db.getProjects()) {
            if (p.getDepartment().equalsIgnoreCase(user.getDepartment())) {
                sb.append("ID: ").append(p.getId()).append("\nTitle: ").append(p.getTitle()).append("\nDesc: ").append(p.getDescription()).append("\nGuide: ").append(p.getGuideTeacher()).append("\n---\n");
            }
        }
        JTextArea ta = new JTextArea(sb.length()==0?"No projects":""+sb.toString());
        ta.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(ta), "Projects", JOptionPane.PLAIN_MESSAGE);
    }
}
