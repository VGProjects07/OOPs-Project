import javax.swing.*;
import java.awt.*;
import models.Project;

public class ProjectEditDialog extends JDialog {
    private DBHelper db;
    private Project project;

    public ProjectEditDialog(JFrame owner, DBHelper db, Project project) {
        super(owner, "Edit Project", true);
        this.db = db; this.project = project;
        init();
    }

    private void init() {
        setSize(500,300); setLocationRelativeTo(getOwner()); setLayout(new BorderLayout());
        JPanel p = new JPanel(new GridBagLayout()); p.setBackground(new Color(40,40,45));
        GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(8,8,8,8);

        c.gridx=0; c.gridy=0; c.anchor = GridBagConstraints.EAST; JLabel idL = new JLabel("ID:"); idL.setForeground(Color.WHITE); p.add(idL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JLabel idV = new JLabel(project.getId()); idV.setForeground(Color.WHITE); p.add(idV, c);

        c.gridx=0; c.gridy=1; c.anchor=GridBagConstraints.EAST; JLabel titleL = new JLabel("Title:"); titleL.setForeground(Color.WHITE); p.add(titleL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField titleF = new JTextField(project.getTitle()==null?"":project.getTitle(), 28); titleF.setBackground(new Color(60,60,60)); titleF.setForeground(Color.WHITE); p.add(titleF, c);

        c.gridx=0; c.gridy=2; c.anchor=GridBagConstraints.NORTHEAST; JLabel descL = new JLabel("Description:"); descL.setForeground(Color.WHITE); p.add(descL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextArea descA = new JTextArea(project.getDescription()==null?"":project.getDescription(), 6, 28); descA.setBackground(new Color(60,60,60)); descA.setForeground(Color.WHITE); p.add(new JScrollPane(descA), c);

        c.gridx=0; c.gridy=3; c.anchor=GridBagConstraints.EAST; JLabel dueL = new JLabel("Due Date (YYYY-MM-DD):"); dueL.setForeground(Color.WHITE); p.add(dueL, c);
        c.gridx=1; c.anchor=GridBagConstraints.WEST; JTextField dueF = new JTextField(project.getDueDate()==null?"":project.getDueDate().toString(), 12); dueF.setBackground(new Color(60,60,60)); dueF.setForeground(Color.WHITE); p.add(dueF, c);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); actions.setOpaque(false);
        JButton save = new JButton("Save"); save.addActionListener(e -> {
            String newTitle = titleF.getText().trim(); String newDesc = descA.getText().trim(); java.time.LocalDate due = null;
            try { String d = dueF.getText().trim(); if (!d.isEmpty()) due = java.time.LocalDate.parse(d); } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD."); return; }
            db.updateProject(project.getId(), newTitle, newDesc, due);
            JOptionPane.showMessageDialog(this, "Project updated.");
            dispose();
        });
        JButton cancel = new JButton("Cancel"); cancel.addActionListener(e -> dispose());
        actions.add(save); actions.add(cancel);

        add(p, BorderLayout.CENTER); add(actions, BorderLayout.SOUTH);
    }
}
