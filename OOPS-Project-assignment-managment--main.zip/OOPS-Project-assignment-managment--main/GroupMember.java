package models;

import java.io.Serializable;

public class GroupMember implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String prn;
    private String department;
    private String division;

    public GroupMember() {}

    public GroupMember(String name, String prn, String department, String division) {
        this.name = name;
        this.prn = prn;
        this.department = department;
        this.division = division;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPrn() { return prn; }
    public void setPrn(String prn) { this.prn = prn; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getDivision() { return division; }
    public void setDivision(String division) { this.division = division; }
}
