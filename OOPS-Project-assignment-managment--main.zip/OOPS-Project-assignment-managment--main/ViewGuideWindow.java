import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import models.User;

public class ViewGuideWindow extends JFrame {
    private DBHelper db;
    private User user;

    public ViewGuideWindow(DBHelper db, User user) { super("View Guide Teachers"); this.db=db; this.user=user; init(); }

    private void init() {
        setSize(620,420); setLocationRelativeTo(null); setMinimumSize(new Dimension(520,360));
        TrailPanel bg = new TrailPanel(); bg.setLayout(new GridBagLayout());
    JPanel card = new RoundedPanel(); card.setLayout(new BorderLayout(10,10)); card.setOpaque(false); card.setPreferredSize(new Dimension(520,320));

    JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT,12,8)); header.setOpaque(false);
    PulsingIcon picon = new PulsingIcon(48,48);
    JLabel iconLabel = new JLabel(new ImageIcon(picon.getImage()));
    Timer iconTimer = new Timer(90, ev -> { picon.pulse(); iconLabel.setIcon(new ImageIcon(picon.getImage())); });
    iconTimer.start();
    header.add(iconLabel);
    JLabel title = new JLabel("Guide Teachers"); title.setForeground(Color.WHITE); title.setFont(title.getFont().deriveFont(Font.BOLD,18f)); header.add(title);

        StringBuilder sb = new StringBuilder();
        for (models.Project p : db.getProjects()) if (p.getDepartment().equalsIgnoreCase(user.getDepartment())) sb.append(p.getTitle()).append(" - ").append(p.getGuideTeacher()).append("\n");
        JTextArea ta = new JTextArea(sb.length()==0?"No projects":sb.toString()); ta.setEditable(false); ta.setBackground(new Color(60,60,60)); ta.setForeground(Color.WHITE);
        JScrollPane content = new JScrollPane(ta, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        content.setBorder(BorderFactory.createEmptyBorder()); content.setOpaque(false); content.getViewport().setOpaque(false);

        card.add(header, BorderLayout.NORTH); card.add(content, BorderLayout.CENTER);
        JScrollPane cs = new JScrollPane(card, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cs.setOpaque(false); cs.getViewport().setOpaque(false); cs.setBorder(BorderFactory.createEmptyBorder()); cs.setPreferredSize(new Dimension(540,340));
        bg.add(cs); add(bg);
    addWindowListener(new WindowAdapter() { @Override public void windowClosed(WindowEvent e) { iconTimer.stop(); } });
    }

    private static class RoundedPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0,0, new Color(35,35,40,220), 0, h, new Color(22,22,26,200));
            g2.setPaint(gp);
            g2.fillRoundRect(0,0,w,h,20,20);
            g2.setColor(new Color(255,255,255,20));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0,0,w-1,h-1,20,20);
            g2.dispose();
        }
    }
}
