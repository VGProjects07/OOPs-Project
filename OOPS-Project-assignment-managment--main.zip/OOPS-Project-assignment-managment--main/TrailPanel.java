import javax.swing.*;
import java.awt.*;
import java.awt.event.HierarchyEvent;
import java.awt.event.MouseEvent;

// Reusable panel that draws a trailing orb following the mouse
public class TrailPanel extends JPanel {
    private double tx = -200, ty = -200;
    private double x = -200, y = -200;
    private java.util.List<double[]> trail = new java.util.ArrayList<>();
    private javax.swing.Timer timer;

    public TrailPanel() {
        setOpaque(true);
        setBackground(Color.BLACK);
        for (int i = 0; i < 20; i++) trail.add(new double[]{x, y});
        timer = new javax.swing.Timer(30, e -> {
            x += (tx - x) * 0.18;
            y += (ty - y) * 0.18;
            trail.add(0, new double[]{x, y});
            if (trail.size() > 30) trail.remove(trail.size() - 1);
            repaint();
        });
        timer.start();
        addHierarchyListener(ev -> {
            if ((ev.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && !isShowing()) timer.stop();
        });

        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                tx = e.getX(); tx = Math.max(0, Math.min(getWidth(), tx));
                ty = e.getY(); ty = Math.max(0, Math.min(getHeight(), ty));
            }
            @Override
            public void mouseDragged(java.awt.event.MouseEvent e) { mouseMoved(e); }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        for (int i = trail.size()-1; i >= 0; i--) {
            double[] p = trail.get(i);
            float alpha = (float) (1.0 - (i/(double)trail.size()));
            int size = (int)(20 * (1.0 - i/(double)trail.size())) + 6;
            g2.setColor(new Color(80, 200, 180, Math.min(255, (int)(alpha*200))));
            g2.fillOval((int)p[0]-size/2, (int)p[1]-size/2, size, size);
        }
        int cx = (int)Math.round(x), cy = (int)Math.round(y);
        for (int i = 8; i >= 1; i--) {
            int size = i * 6 + 6;
            g2.setColor(new Color(80, 200, 180, Math.min(255, i*18)));
            g2.fillOval(cx - size/2, cy - size/2, size, size);
        }
        g2.setColor(new Color(220, 255, 230)); g2.fillOval(cx-6, cy-6, 12, 12);
        g2.dispose();
    }
}
