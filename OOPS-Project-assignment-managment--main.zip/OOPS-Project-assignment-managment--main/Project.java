package models;

import java.io.Serializable;
import java.time.LocalDate;

public class Project implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String title;
    private String description;
    private String department;
    private String guideTeacher;
    private LocalDate dueDate;
    private int groupSize;

    public Project(String id, String title, String description, String department, String guideTeacher) {
        this(id, title, description, department, guideTeacher, null);
    }

    public Project(String id, String title, String description, String department, String guideTeacher, LocalDate dueDate) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.department = department;
        this.guideTeacher = guideTeacher;
        this.dueDate = dueDate;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getDepartment() { return department; }
    public String getGuideTeacher() { return guideTeacher; }
    public LocalDate getDueDate() { return dueDate; }
    public int getGroupSize() { return groupSize; }

    // setters for editable fields
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setGuideTeacher(String guideTeacher) { this.guideTeacher = guideTeacher; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setGroupSize(int groupSize) { this.groupSize = groupSize; }
}
