import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import models.Project;
import models.User;

public class AddProjectWindow extends JFrame {
    private DBHelper db;
    private User user;

    public AddProjectWindow(DBHelper db, User user) {
        super("Add Project");
        this.db = db; this.user = user;
        // Only admins can open this window
        if (user == null || !"admin".equalsIgnoreCase(user.getRole())) {
            JOptionPane.showMessageDialog(null, "Only admins can add projects.", "Access denied", JOptionPane.WARNING_MESSAGE);
            SwingUtilities.invokeLater(() -> { dispose(); });
            return;
        }
        init();
    }

    private void init() {
        setSize(620, 420);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(520, 360));

        TrailPanel bg = new TrailPanel();
        bg.setLayout(new GridBagLayout());

        // Card panel with rounded corners and subtle gradient
        JPanel card = new RoundedPanel();
        card.setLayout(new BorderLayout(12,12));
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(520, 320));

        // Header with pulsing icon and title
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        header.setOpaque(false);
    PulsingIcon icon = new PulsingIcon(64, 64);
    JLabel iconLabel = new JLabel(new ImageIcon(icon.getImage()));
    // update icon periodically
    Timer iconTimer = new Timer(80, e -> { icon.pulse(); iconLabel.setIcon(new ImageIcon(icon.getImage())); });
    iconTimer.start();

    JLabel title = new JLabel("Add New Project");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
    title.setForeground(Color.WHITE);
    // right side success label placeholder
    JLabel success = new JLabel("Project added!");
    success.setForeground(new Color(200,255,200));
    success.setFont(success.getFont().deriveFont(Font.BOLD, 16f));
    success.setVisible(false);

    JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
    left.setOpaque(false);
    left.add(iconLabel);
    left.add(title);

    JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 8));
    right.setOpaque(false);
    right.add(success);

    header.setLayout(new BorderLayout());
    header.add(left, BorderLayout.WEST);
    header.add(right, BorderLayout.EAST);

    // Form area — use inner panel and scroll pane to avoid clipping
    JPanel form = new JPanel(new GridBagLayout());
    form.setOpaque(false);
    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(8,10,8,10);

    // Label column - anchored right
    c.gridx = 0; c.gridy = 0; c.anchor = GridBagConstraints.EAST; c.weightx = 0.0;
    JLabel idL = styledLabel("ID:"); idL.setPreferredSize(new Dimension(140, idL.getPreferredSize().height)); form.add(idL, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; c.weightx = 1.0; c.fill = GridBagConstraints.HORIZONTAL; JTextField idF = styledField(30); form.add(idF, c);

    c.gridx = 0; c.gridy = 1; c.anchor = GridBagConstraints.EAST; JLabel titleLbl = styledLabel("Title:"); titleLbl.setPreferredSize(new Dimension(140, titleLbl.getPreferredSize().height)); form.add(titleLbl, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField titleF = styledField(30); form.add(titleF, c);

    c.gridx = 0; c.gridy = 2; c.anchor = GridBagConstraints.EAST; JLabel descLbl = styledLabel("Description:"); descLbl.setPreferredSize(new Dimension(140, descLbl.getPreferredSize().height)); form.add(descLbl, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField descF = styledField(30); form.add(descF, c);

    c.gridx = 0; c.gridy = 3; c.anchor = GridBagConstraints.EAST; JLabel deptLbl = styledLabel("Department:"); deptLbl.setPreferredSize(new Dimension(140, deptLbl.getPreferredSize().height)); form.add(deptLbl, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField deptF = styledField(30); deptF.setText(user.getDepartment()); form.add(deptF, c);

    c.gridx = 0; c.gridy = 4; c.anchor = GridBagConstraints.EAST; JLabel guideLbl = styledLabel("Guide:"); guideLbl.setPreferredSize(new Dimension(140, guideLbl.getPreferredSize().height)); form.add(guideLbl, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField guideF = styledField(30); guideF.setText(user.getUsername()); form.add(guideF, c);

    c.gridx = 0; c.gridy = 5; c.anchor = GridBagConstraints.EAST; JLabel dueLbl = styledLabel("Due Date (YYYY-MM-DD):"); dueLbl.setPreferredSize(new Dimension(140, dueLbl.getPreferredSize().height)); form.add(dueLbl, c);
    c.gridx = 1; c.anchor = GridBagConstraints.WEST; JTextField dueF = styledField(30); dueF.setToolTipText("yyyy-mm-dd"); form.add(dueF, c);

    // Put form into a scroll pane so it never clips
    JScrollPane formScroll = new JScrollPane(form, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    formScroll.setOpaque(false); formScroll.getViewport().setOpaque(false); formScroll.setBorder(BorderFactory.createEmptyBorder());
    formScroll.setPreferredSize(new Dimension(480, 200));

        // Action row
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        actions.setOpaque(false);
        JButton addBtn = new JButton("Add Project"); styleMainButton(addBtn);
        JButton cancelBtn = new JButton("Cancel"); styleGhostButton(cancelBtn);
        actions.add(addBtn); actions.add(cancelBtn);

    // reuse success label from header (shows on the right)

        // Wire actions
        addBtn.addActionListener(e -> {
            String id = idF.getText().trim();
            String ttl = titleF.getText().trim();
            if (id.isEmpty() || ttl.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please provide at least ID and Title.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            java.time.LocalDate due = null;
            try {
                String d = dueF.getText().trim(); if (!d.isEmpty()) due = java.time.LocalDate.parse(d);
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Invalid due date format. Use YYYY-MM-DD.", "Date parse error", JOptionPane.ERROR_MESSAGE); return; }
            Project p = new Project(id, ttl, descF.getText().trim(), deptF.getText().trim(), guideF.getText().trim(), due);
            db.addProject(p);
            // show success briefly and also a dialog for clarity
            success.setVisible(true);
            repaint();
            JOptionPane.showMessageDialog(this, "Project added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            // clear fields
            idF.setText(""); titleF.setText(""); descF.setText("");
            Timer t = new Timer(1400, ev -> { success.setVisible(false); }); t.setRepeats(false); t.start();
        });
        cancelBtn.addActionListener(e -> dispose());

    card.add(header, BorderLayout.NORTH);
    card.add(formScroll, BorderLayout.CENTER);
        card.add(actions, BorderLayout.SOUTH);

    // Wrap the card in a scroll pane so the whole box can scroll if window is small
    JScrollPane cardScroll = new JScrollPane(card, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    cardScroll.setOpaque(false);
    cardScroll.getViewport().setOpaque(false);
    cardScroll.setBorder(BorderFactory.createEmptyBorder());
    cardScroll.setPreferredSize(new Dimension(540, 340));
    bg.add(cardScroll);
        add(bg);

        // Stop icon timer when window hidden
    addWindowListener(new WindowAdapter() { @Override public void windowClosed(WindowEvent e) { iconTimer.stop(); } });
    }

    private JLabel styledLabel(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(Color.LIGHT_GRAY);
        return l;
    }

    private JTextField styledField(int cols) {
        JTextField f = new JTextField(cols);
        f.setBackground(new Color(60,60,60));
        f.setForeground(Color.WHITE);
        f.setBorder(BorderFactory.createEmptyBorder(6,8,6,8));
        return f;
    }

    private void styleMainButton(JButton b) {
        b.setBackground(new Color(28, 160, 100)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(8,14,8,14));
    b.addMouseListener(new java.awt.event.MouseAdapter(){ @Override public void mouseEntered(java.awt.event.MouseEvent e){ b.setBackground(new Color(38,200,120)); } @Override public void mouseExited(java.awt.event.MouseEvent e){ b.setBackground(new Color(28,160,100)); } });
    }

    private void styleGhostButton(JButton b) {
        b.setBackground(new Color(80,80,80)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(8,12,8,12));
    b.addMouseListener(new java.awt.event.MouseAdapter(){ @Override public void mouseEntered(java.awt.event.MouseEvent e){ b.setBackground(new Color(100,100,100)); } @Override public void mouseExited(java.awt.event.MouseEvent e){ b.setBackground(new Color(80,80,80)); } });
    }

    // Rounded panel with gradient background
    private static class RoundedPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0,0, new Color(35,35,40,220), 0, h, new Color(22,22,26,200));
            g2.setPaint(gp);
            g2.fillRoundRect(0,0,w,h,20,20);
            g2.setColor(new Color(255,255,255,20));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0,0,w-1,h-1,20,20);
            g2.dispose();
            // Do NOT call super.paintComponent(g) here because we draw custom background
            // and want child components to be painted on top of it.
        }
    }

    // Simple pulsing icon generator
    private static class PulsingIcon {
        private int w,h; private BufferedImage img; private float phase = 0f;
        public PulsingIcon(int w, int h){ this.w=w; this.h=h; img = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB); draw(); }
        public void pulse(){ phase += 0.12f; draw(); }
        private void draw(){ Graphics2D g = img.createGraphics(); g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); g.setComposite(AlphaComposite.Clear); g.fillRect(0,0,w,h); g.setComposite(AlphaComposite.SrcOver);
            // background circle
            g.setColor(new Color(60,120,200)); g.fillOval(4,4,w-8,h-8);
            // book/project glyph
            g.setColor(new Color(255,255,255,220)); int bx = w/4, by = h/3; g.fillRect(bx, by, w/2, h/10); g.fillRect(bx, by + h/8, w/2, h/10);
            // pulsing halo
            int r = 10 + (int)(6*Math.abs(Math.sin(phase)));
            g.setColor(new Color(80,180,220, 90)); g.fillOval(w/2 - r, h/2 - r, r*2, r*2);
            g.dispose(); }
        public BufferedImage getImage(){ return img; }
    }

}
